//
//  ContentView.swift
//  fintechlab_Satwik
//
//  Created by Satwik Sinha on 5/5/24.
//

import SwiftUI

struct ContentView: View {
    @State private var companyTicker: String = ""
    @State private var insightsText: String = "Enter a company ticker to get insights."
    
    var body: some View {
        VStack {
            TextField("Enter Company Ticker", text: $companyTicker)
                .padding()
                .textFieldStyle(RoundedBorderTextFieldStyle())
            
            Button("Load Insights") {
                loadInsights(for: companyTicker)
            }
            .padding()
            .foregroundColor(.white)
            .background(Color.blue)
            .cornerRadius(8)
            
            ScrollView {
                Text(insightsText)
                    .padding()
            }
        }
        .padding()
    }
    
    func loadInsights(for ticker: String) {
        // This function should be implemented to fetch insights from the backend
        // For demonstration purposes, it simply updates the insightsText with a placeholder message
        insightsText = "Loading insights for \(ticker)..."
        
        // Here, you would typically perform an HTTP request to your Flask backend
        // and update insightsText with the response data
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
