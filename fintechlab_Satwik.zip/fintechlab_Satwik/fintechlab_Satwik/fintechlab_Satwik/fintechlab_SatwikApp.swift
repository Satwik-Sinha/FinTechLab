//
//  fintechlab_SatwikApp.swift
//  fintechlab_Satwik
//
//  Created by Satwik Sinha on 5/5/24.
//
import WebKit
import SwiftUI

@main
struct fintechlab_SatwikApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
